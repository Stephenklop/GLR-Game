<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Home | GLR game</title>
  </head>
  <body>
    <header>
      <nav>
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#">Teams</a></li>
          <li><a href="#">Agenda</a></li>
          <li><a href="#">Toernooischema</a></li>
          <li><a href="#">Over ons</a></li>
          <li><a href="#">Login</a></li>
          <li><a href="#">Donate</a></li>
        </ul>
      </nav>
    </header>
    <main>

    </main>
    <footer>
      <img src="../img/twitter_icon.png" alt="">
      <img src="../img/facebook_icon.png" alt="">
      <img src="../img/instagram_icon.png" alt="">
    </footer>
  </body>
</html>
