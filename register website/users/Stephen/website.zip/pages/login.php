<!DOCTYPE html>
<html lang="nl" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login | GLR-game</title>
  </head>
  <body>
    <header>

    </header>
    <main>
      <section class="login">
        <figure>
          <img src="" alt="GLR-GAME">
        </figure>
        <form class="" action="index.html" method="post">

        </form>
      </section>
    </main>
    <footer>

    </footer>
  </body>
</html>
