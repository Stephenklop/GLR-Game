<header>
  <nav>
    <ul>
      <li><a href="#">Home</a></li>
      <li><a href="#">Teams</a></li>
      <li><a href="#">Agenda</a></li>
      <li><a href="#">Schema</a></li>
      <li class="figure">
        <figure>
          <img src="../img/logo.png" alt="">
        </figure>
      </li>
      <li><a href="#">Shop</a></li>
      <li><a href="#">Over</a></li>
      <li><a href="#">Login</a></li>
      <li class="move"><a href="#" class="donate">Donate</a></li>
    </ul>
  </nav>
  <section class="headerinfo">
    <h1>Inschrijven</h1>
  </section>
</header>
